package com.example.projectbaru.ui.slideshow;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.widget.LinearLayout;

import com.example.projectbaru.R;
import com.example.projectbaru.databinding.ActivityMainBinding;

public class SlideshowFragment extends Fragment {

    @NonNull ActivityMainBinding binding;

    @Override
    public void onCreate(Bundle saveIntanceState) {
        super.onCreate(saveIntanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String[] playerName = {"GOALKEEPER","","","DEFENDER","","","","","","","","","MIDFILDER","","","","","","","","","STRIKER","","","","","","HEAD COACH"};
        int[] playerImage = {R.drawable.img1,R.drawable.keeper2,R.drawable.keeper3,R.drawable.def1,R.drawable.def2,R.drawable.def3,R.drawable.def4,R.drawable.def5,R.drawable.def6,R.drawable.def7,R.drawable.def8,R.drawable.def9,
                R.drawable.mid1,R.drawable.mid2,R.drawable.mid3,R.drawable.mid4,R.drawable.mid5,R.drawable.mid6,R.drawable.mid7,R.drawable.mid8,
                R.drawable.s1,R.drawable.s2,R.drawable.s3,R.drawable.s4,R.drawable.s5,R.drawable.s6,R.drawable.hc};

        GridAdapter gridAdapter = new GridAdapter(SlideshowFragment.this, playerName,playerImage);
        binding.gridView.setAdapter(gridAdapter);

    }

    private void setContentView(LinearLayout fragment_slideshow) {
    }

    public Object getSystemService(String layoutInflaterService) {
        return null;
    }
}

