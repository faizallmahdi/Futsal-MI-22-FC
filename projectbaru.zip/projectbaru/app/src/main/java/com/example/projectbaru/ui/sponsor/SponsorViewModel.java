package com.example.projectbaru.ui.sponsor;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class SponsorViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public SponsorViewModel() {
        mText = new MutableLiveData<>();

    }

    public LiveData<String> getText() {
        return mText;
    }
}